@include('layouts.header')
@yield('section')
@include('layouts.footer')
