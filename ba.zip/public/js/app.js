const calendarConfig = {
    container: 'calendar',
    months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    weekDays: ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"],
}
// const calendar = new RolyartCalendar(calendarConfig);


